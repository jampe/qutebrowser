function editElementObject(...args) {
    editElementObjectFn(false, ...args);
}