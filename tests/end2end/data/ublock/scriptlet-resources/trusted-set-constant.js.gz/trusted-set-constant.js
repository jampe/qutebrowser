function trustedSetConstant(
    ...args
) {
    setConstantFn(true, ...args);
}