function jsonEditXhrRequest(jsonq = '', ...args) {
    jsonEditXhrRequestFn(false, jsonq, ...args);
}