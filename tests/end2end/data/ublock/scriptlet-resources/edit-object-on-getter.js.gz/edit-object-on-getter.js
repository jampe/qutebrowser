function editObjectOnGetter(...args) {
    editObjectOnGetterFn(false, ...args);
}