function windowNameDefuser() {
    if ( window === window.top ) {
        window.name = '';
    }
}