function editInboundObject(propChain = '', argPos = '', jsonq = '') {
    editInboundObjectFn(false, propChain, argPos, jsonq);
}