function setConstant(
    ...args
) {
    setConstantFn(false, ...args);
}