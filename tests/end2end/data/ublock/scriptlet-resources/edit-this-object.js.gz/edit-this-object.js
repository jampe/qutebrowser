function editThisObject(...args) {
    editThisObjectFn(false, ...args);
}