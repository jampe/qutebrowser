function trustedEditObjectOnSetter(...args) {
    editObjectOnSetterFn(true, ...args);
}