function trustedEditObjectOnGetter(...args) {
    editObjectOnGetterFn(true, ...args);
}