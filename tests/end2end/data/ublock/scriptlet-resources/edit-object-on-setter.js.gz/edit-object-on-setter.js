function editObjectOnSetter(...args) {
    editObjectOnSetterFn(false, ...args);
}