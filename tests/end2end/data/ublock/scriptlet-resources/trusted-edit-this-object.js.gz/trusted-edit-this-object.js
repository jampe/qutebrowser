function trustedEditThisObject(...args) {
    editThisObjectFn(true, ...args);
}