function trustedEditElementObject(...args) {
    editElementObjectFn(true, ...args);
}