function trustedEditOutboundObject(propChain = '', jsonq = '') {
    editOutboundObjectFn(true, propChain, jsonq);
}