function breakOnCall(target) {
    proxyApplyFn(target, function(context) {
        debugger;  // eslint-disable-line no-debugger
        return context.reflect();
    });
}