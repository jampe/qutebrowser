function trustedPreventXhr(...args) {
    return preventXhrFn(true, ...args);
}