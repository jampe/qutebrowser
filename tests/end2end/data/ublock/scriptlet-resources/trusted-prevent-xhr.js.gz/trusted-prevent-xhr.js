function trustedPreventXhr(...args) {
    preventXhrFn(true, ...args);
}