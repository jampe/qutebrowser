function preventFetch(...args) {
    preventFetchFn(false, ...args);
}