function preventXhr(...args) {
    return preventXhrFn(false, ...args);
}