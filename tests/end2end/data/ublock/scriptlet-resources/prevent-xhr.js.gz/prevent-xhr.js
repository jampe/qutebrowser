function preventXhr(...args) {
    preventXhrFn(false, ...args);
}